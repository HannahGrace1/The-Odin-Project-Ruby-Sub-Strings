dictionary = ['hello','what','paris','new york city','london','bridge','cartier','armani','yes','no','belong','real','the','state','plane','train','rain','snow','sunny','philadephia','where','are','you','from','organize','southern','food']

def substrings(string, dictionary)
  hash = {}
  dictionary.each do |word|
    count = string.downcase.scan(word).size  
    hash[word] = count unless count == 0
  end
  hash
end

string = "The food in the southern states is not the same as the food in Paris, New York City, and Philadelphia."

puts substrings(string, dictionary)
